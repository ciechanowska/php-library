<?php
include ('connect.php');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script src="style.fix.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<title>Cottage</title>
</head>
<body>
<div id="wrapper">
  <header>
	<div id"=baner">
    	<h1>
        	<a href="">
            <span>gården</span>
    		<img src="img/baner.jpg">
    		</a>
        </h1>
    </div>
  </header>
 <nav>
 <?php
  include ('navigation.php' );
  ?>
 </nav> 
<section>
<div class="text2"> 
         <h1>Vores address</h1>
             Den lille gård Østre Bakkevænge3<br>
             7650 Bøvlingbjerg
          <h1>Telefon:</h1>
             tlf.12345678
          <h1>E-mail:</h1>
             fake@gården.dk
          </div> 
 <article> 
  <iframe src="http://maps.google.dk/maps?f=q&amp;source=s_q&amp;hl=da&amp;geocode=&amp;q=Stabyvej+76,+Husby,+6990+Ulfborg&amp;aq=&amp;sll=56.273086,8.207004&amp;sspn=0.001279,0.004128&amp;
  ie=UTF8&amp;hq=&amp;hnear=Stabyvej+76,+6990+Ulfborg&amp;t=m&amp;ll=56.273433,8.206787&amp;spn=0.019301,0.025835&amp;z=14&amp;iwloc=&amp;output=embed"></iframe>  
     <?php
if (isset($_POST['submit']))
{
     $navn= $_POST['navn'];
	 $email= $_POST['email'];
	 $besked= $_POST['besked'];
	 $oprette=$_POST['dtstart'];
	 

	 
	 $sql="INSERT INTO kontakt (Navn, Email, Besked, Oprette) VALUES ('$navn', '$email', '$besked', '$oprette')";
	 mysqli_query($db, $sql);
}

?>
    <?php 
 ?>
<form action= "" id="kontaktform" method= "post" >
 <fieldset>
     <legend>Kontakt os</legend>
     <label for= "navn" >Navn:
     <input type= "text" name="navn" id="navn" required value= "<?php if(isset($_POST['submit'])) { echo $navn; } ?>" />
     <?php
    if(isset($_POST['submit' ]) && $navn == "") {
         echo '<span class="error" id="navn">Udfyld venligst navn</span>';
 }
 ?>
 </label>
 <label for= "email" >Email:
   <input type= "email" name="email" id="email" required value= "<?php if(isset($_POST['submit'])) { echo $email; } ?>" />
   <?php
  if(isset($_POST['submit' ]) && $email == "" ) {
      echo '<span class="error" id="email">Udfyld venligst email</span>';
 }
 if(isset($_POST['submit' ]) && !filter_var ($email,FILTER_VALIDATE_EMAIL) && $email != "") {
     echo '<span class="error" id="email">Udfyld venligst en gyldig email</span>';
 }
 ?>
 </label>
 
 <label for= "besked" >Besked:
      <textarea name= "besked" id="besked" rows= "10" cols="30" required> <?php if(isset($_POST['submit'])) { echo $besked; } ?></textarea>
 <?php
   if(isset($_POST['submit' ]) && $besked == "") {
       echo '<span class="error" id="besked">Skriv venligst en besked</span>';
 }
 ?>
   </label>
   
   <label for= "oprette" >Dato:
      <input id="dtstart" name="dtstart" type="date" <?php if(isset($_POST['submit'])) { echo $oprette; } ?>/>
 <?php
   if(isset($_POST['submit' ]) && $oprette == "") {
       echo '<span class="error" id="oprette">Vælg venligst dato</span>';
 }
 ?>
   </label>
    </fieldset>
<input type= "submit" name="submit" id="submit" value="Send" />
</form>
<article>

</section> <!--slut"section-->
<footer>
<?php
 include('footer.php');
 ?>
</footer>
</div>
</body>
</html>