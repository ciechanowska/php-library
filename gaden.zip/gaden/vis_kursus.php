<h1>Hele kursus</h1>
<a href="kurser.php">Tilbage</a><br>
<article>
<?php
   $id = $_GET['id'];
   $result = mysqli_query($db,"SELECT * FROM kurser WHERE id=$id");
  while ($myrow = mysqli_fetch_array($result)) {
  ?>

<?php echo $myrow["dato"]?><br>
<h1><?php echo $myrow["titel"]?></h1><br>
<h1><?php echo $myrow["tid"]?></h1><br>
<p class="tekst3">
<?php echo $myrow["indhold"]?></p><br>

<?php

 }
 ?>
<a href="tilmeld.php">Tilmeld dig her</a>
</article>