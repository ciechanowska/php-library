<?php
include ('connect.php');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script src="style.fix.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<title>Cottage</title>
</head>
<body>
<div id="wrapper">
  <header>
	<div id"=baner">
    	<h1>
        	<a href="">
            <span>gården</span>
    		<img src="img/baner.jpg">
    		</a>
        </h1>
    </div>
  </header>
 <nav>
 <?php
  include ('navigation.php' );
  ?>
 </nav> 
<section class="content">
<?php
  if(isset($_GET['id'])){
	include( 'vis.php');
  }else{
	include ('event.php');
  }
?>
</section> <!--slut"section-->
<footer>
<?php
 include('footer.php');
 ?>
</footer>
</div>
</body>
</html>