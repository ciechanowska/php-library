<h1>Arrangementer</h2>
<?php

$result=mysqli_query($db,"SELECT* FROM arrangementer");

 while($myrow=mysqli_fetch_array ($result)){
?>

<br><?php echo $myrow["dato"]?>
<h1><?php echo $myrow["titel"]?></h1>
<a href="?id=<?php echo $myrow['id'];?>">vis</a>

<?php
 }
 ?>