<!doctype html>
<html>
<head>
<meta charset="utf-8"><link rel="stylesheet" type="text/css" href="style_formular.css">
<title>Formular</title>

</head>
<body>

<?php
include ('connect.php');
?>
<article>
 <?php
if (isset($_POST['submit']))
{
	
     $fornavn=$_POST['fornavn'];
	 $efternavn=$_POST['efternavn'];  
	 $email=$_POST['email'];
	 $phone=$_POST['phone'];
	 $alder=$_POST['alder'];
	 $koen=$_POST['koen'];
	 $titel=$_POST['titel'];
	 $opholdstype=$_POST['opholdstype'];

	 
	 $sql="INSERT INTO formular (fornavn, efternavn, email, phone, alder, koen, titel, opholdstype) VALUES ('$fornavn', '$efternavn', '$email', '$phone', '$alder', '$koen', '$titel', '$opholdstype')";
	 mysqli_query($db, $sql);
}

?>
    <?php 
 ?>
<div id="form">
<h1>Formular </h1>
<form action= "" id="kontaktform" method= "post" >
<fieldset>
        <legend>"fornavn" og "efternavn"</legend>
         <label for="fornavn">Fornavn:</label>
         <input type="text" id="fornavn" name="fornavn" placeholder="Skriv dit fornavn" required value= "<?php if(isset($_POST['submit'])) { echo $fornavn; } ?>"/>
     <?php
    if(isset($_POST['submit' ]) && $fornavn == "") {
         echo '<span class="error" id="fornavn">Udfyld venligst fornavn</span>';
 }
 ?>
         <label for="efternavn">Efternavn</label>
         <input type="text" id="efternavn" name="efternavn" placeholder="Skriv dit efternavn" required value= "<?php if(isset($_POST['submit'])) { echo $efternavn; } ?>"/>
     <?php
    if(isset($_POST['submit' ]) && $efternavn == "") {
         echo '<span class="error" id="efternavn">Udfyld venligst eternavn</span>';
 }
 ?>
     </fieldset>
     
     <fieldset>
        <legend>"email" og "tel"</legend>
        <label for="email">Email-addresse</label>
        <input id="email" name="email" type="email" <?php if(isset($_POST['submit'])) { echo $email; } ?>/>
     <?php
    if(isset($_POST['submit' ]) && $email == "") {
         echo '<span class="error" id="email">Udfyld venligst email</span>';
 }
 ?>              
        <label for="phone">Telefon</label>
       <input id="phone" name="phone" type="tel" placeholder="+45 12345678" pattern="^\+45 [1-9][0-9]{7}$" <?php if(isset($_POST['submit'])) { echo $phone; } ?>/>
     <?php
    if(isset($_POST['submit' ]) && $phone == "") {
         echo '<span class="error" id="phone">Udfyld venligst phone</span>';
 }
 ?>                              
     </fieldset> 
     
      <fieldset>
       <legend>"select list"</legend>
        <label for="alder">Min alder?</label>
        <select name="alder" id="alder" <?php if(isset($_POST['submit'])) { echo $alder; } ?>/>
     <?php
    if(isset($_POST['submit' ]) && $alder == "") {
         echo '<span class="error" id="alder">Select venligst alder</span>';
 }
 ?>                                                                                                                
        <option value="10-19" selected>10-19</option>
        <option value="20-39">20-39</option>
        <option value="40-59">40-59</option>
        <option value="60">60+</option>
        </select>
        </fieldset>
        
          
     <fieldset>
        <legend>"køn"</legend>
        <label for="kvinde" class="no_block">Kvinde:</label>
          <input type="radio" name="koen" id="kvinde" value="0" required value= "<?php if(isset($_POST['submit'])) { echo $koen; } ?>"/>
  
        <label for="mand" class="no_block">Mand:</label>
           <input type="radio" name="koen" id="mand" value="1"  required value= "<?php if(isset($_POST['submit'])) { echo $koen; } ?>"/>          
    </fieldset>
     
      <fieldset>
        <legend>"kursus og arrangement"</legend>
        <label for="titel">Titel:</label>
        <textarea name="titel" id="titel" placeholder="Skriv titel af kursus eller arrangement her..." required><?php if(isset($_POST['submit'])) { echo $titel; } ?></textarea>
       </fieldset>
    
    <fieldset>
        <legend>"select list"</legend>
        <label for="opholdstype">Min opholdstype:</label>
        <select name="opholdstype" id="opholdstype" <?php if(isset($_POST['submit'])) { echo $opholdstype; } ?>/>
     <?php
    if(isset($_POST['submit' ]) && $opholdstype == "") {
         echo '<span class="error" id="opholdstype">Select venligst opholdstype</span>';
 }
 ?>                                                      
            <option value="privat>5">Privat > 5 personer</option>
            <option value="privat<5">Privat < 5 personer</option>
            <option value="grupper">Grupper</option>
            </select>
      </fieldset>
      
      <fieldset>
     <legend>"submit" og "reset"</legend>
     <input type="submit" name="submit" value="Send">
     <input type="reset" value="Fortryd">
  </fieldset>
  </form>
 </div>
</article>
<div id="links">
 <a href="kurser.php">Tilbage til kurser</a><br>
 <a href="arrangementer.php">Tilbage til arrangementer</a></div>
</body>
</html>
     