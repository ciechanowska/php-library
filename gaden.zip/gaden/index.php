<?php
include ('connect.php');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script src="style.fix.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<title>Cottage</title>
</head>
<body>
<div id="wrapper">
  <header>
	<div id"=baner">
    	<h1>
        	<a href="">
            <span>gården</span>
    		<img src="img/baner.jpg">
    		</a>
        </h1>
    </div>
  </header>
 <nav>
 <?php
  include ('navigation.php' );
  ?>
 </nav> 
<section>
<?php
 include ('galleri.php');
 ?>
<p class="text">
 <p>Vi er en lille gård, der tilbyder et afbræk i en hektisk hverdag.  <p>På vores gård er det muligt at detage i kurser der får dig tilbage i kontakt med naturen,
 finder din indre stenaldermand og mange andre kurser der udnytter den utrolig smukke natur, der omkranser vores lille gård.</p>  
<p> Vi tilbyder også wellness hold med spa, massage og alt der hører til kroppens forkælelse.</p> 

</section> <!--slut"section-->
<footer>
<?php
 include('footer.php');
 ?>
</footer>
</div>
</body>
</html>