<h1>Kurser</h1>
<?php

$result=mysqli_query($db,"SELECT* FROM kurser");

 while($myrow=mysqli_fetch_array ($result)){
?>

<br><h1><?php echo $myrow["titel"]?></h1>
<?php echo $myrow["tid"]?><br>
<a href="?id=<?php echo $myrow['id'];?>">vis</a>

<?php
 }
 ?>