<div id="galleri">
<ul class="gallery">
      <li><a href="#"><img src="img/g1.jpg" width="200" height="200" alt="b1"/></a></li>
      <li><a href="#"><img src="img/g2.jpg" width="200" height="200" alt="b1"/></a></li>
     <li><a href="#"><img src="img/g3.jpg" width="200" height="200" alt="b1"/></a></li>
     <li><a href="#"><img src="img/g4.jpg" width="200" height="200" alt="b1"/></a></li>
     <li><a href="#"><img src="img/g5.jpg" width="200" height="200" alt="b1"/></a></li>
     <li><a href="#"><img src="img/g6.jpg" width="200" height="200" alt="b1"/></a></li>
    <li><a href="#"><img src="img/g7.jpg" width="200" height="200" alt="b1"/></a></li>
    <li><a href="#"><img src="img/g8.jpg" width="200" height="200" alt="b1"/></a></li>
    <li><a href="#"><img src="img/g9.jpg" width="200" height="200" alt="b1"/></a></li>
 </ul>
 </div>
