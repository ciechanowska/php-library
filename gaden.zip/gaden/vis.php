<h1>Hele arrangemant</h1>
<a href="arrangementer.php">Tilbage</a>
<h1>Tilmeld</h1>
<a href="tilmeld.php">Tilmeld dig her</a><br>
<article>
<?php
   $id = $_GET['id'];
   $result = mysqli_query($db,"SELECT * FROM arrangementer WHERE id=$id");
  while ($myrow = mysqli_fetch_array($result)) {
  ?>

<?php echo $myrow["dato"]?><br>
<h1><?php echo $myrow["titel"]?></h1>
<h1><?php echo $myrow["tid"]?> </h1><br>
<p class="tekst3">
<?php echo $myrow["indhold"]?></p><br>
<div id="ar">
<img src='img/<?php echo $myrow["billede"]?>' alt="<?php echo $myrow["billede"]?>"></div>
<?php
}
 ?>
</article>
