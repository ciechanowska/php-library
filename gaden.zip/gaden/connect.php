<?php
$db = mysqli_connect ("localhost" , "root" ,"" ,"gaden" );
//mysqli_connect("localhost","brugernavn","adgangskode";"databasenavn")
mysqli_set_charset ($db,'utf8' );
?>