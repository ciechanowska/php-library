<ul id="navigation">
 <li><a href="index.php?id=1">Hjem</a></li>
 <li><a href="#">Vi tilbyder</a>
      <ul>
          <li><a href="arrangementer.php">Arrangementer</a></li>
          <li><a href="kurser.php">Kurser</a></li>
          
       </ul>
       </li>
       <li><a href="kontakt.php">Kontakt os</a></li>
      
 </ul>
       