// JavaScript Document
//Funktion der kan hente data fra en fil og indsætte det på siden
function get_feeds(){
	var forbindelse = null;
	if (windows.XMLHttpRequest){
		forbindelse = new XMLHttpRequest();
	}
	else if (window.ActiveXObject)
	{
		forbindelse = new ActiveXObject("Microsoft.XMLHttp");
	}
	if(forbindelse){
		forbindelse.open("GET","rss_reader_applikationen.php");
		forbindelse.setRequestHeader("Content-Type", "application/x-www-forum-urlencoded");
		forbindelse.onreadystatechange = function(){
			if (forbindelse.readyState == 4 && forbindelse.status == 200){
				document.getElementById("feeds").innerHTML = forbindelse.responseText;
				delete(forbindelse);
			}
			}
			forbindelse.send(null);
	}
	return false;
}
window.onload = function(){
	get_feeds();
	setInterval("get_feeds()", 60 * 1000);
}