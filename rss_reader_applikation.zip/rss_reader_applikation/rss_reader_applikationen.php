<?php include 'administrations_panel/db_conection.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script src="ajax.js"></script>
<title>RSS Reader Applikationen</title>
</head>
<body>

<section>
<article>


   <span class="">Siden indlæst:<?php echo date("h:i:s");?></span>
   <div id="feeds"><p>Her der kommer andet tekst...</p>
   </div>
   
   
   
   
   
   
   <?php
$rss = simplexml_load_file('http://www.dr.dk/Nyheder/Service/feeds/Kultur');
	echo '<h2>'.$rss->channel->title.'</h2>';
	foreach ($rss->channel->item as $item)
	{
	echo '<h3>'.$item->title.'</h3>';
	echo '<p>'.$item->description.'</p>';
	
	}
?>
<hr/>
</article>
</section>



<?php
$sql_feeds="SELECT * FROM admin";
$result_feeds = mysqli_query($connection, $sql_feeds);
while($row_feeds = mysqli_fetch_assoc($result_feeds)) 
{
 $feedFraDB = $row_feeds['feed_url']; 
 ?>
 <section class="feed">
 <?php
$rss = simplexml_load_file($feedFraDB);
	echo '<h2>'.$rss->channel->title.'</h2>';
	foreach ($rss->channel->item as $item)
	{
	echo "<article>";
	echo '<h3>'.$item->title.'</h3>';
	echo '<p>'.$item->description.'</p>';
	echo "</article>";
	
	}
?>
</section>
<hr/>
<?php
}
?>
</body>
</html>