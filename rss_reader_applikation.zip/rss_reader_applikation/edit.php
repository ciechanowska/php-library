<?php include 'administrations_panel/db_conection.php';?>
<!doctype html>
<html>
     <head>
       
       <title>CRUD</title>
</head>

<body>

<?php
        $feed_titel="";
		$feed_url="";
		
    if(isset($_GET['feed_id'])){
		$feed_id=$_GET['feed_id'];
		
		
		if(isset($_POST['submit']))
		{
			$feed_titel=$_POST['feed_titel'];
			$feed_url=$_POST['feed_url'];
		
			
			echo $sql="UPDATE admin SET feed_titel='$feed_titel', feed_url='$feed_url' WHERE feed_id=$feed_id";
			mysqli_query($connection, $sql);
			
		}
		else{ $sql="SELECT * FROM admin WHERE feed_id=$feed_id";
             $result= mysqli_query($connection, $sql);
             $row=mysqli_fetch_array($result);
			 
			 
			 $feed_titel=$row['feed_titel'];
			$feed_url=$row['feed_url'];
			
			 }
	}
?>


         <form method="POST">
         <p>feed_titel:</p>
         <input type="text" name="feed_titel" value="<?php echo $feed_titel ?>"/><br>
        
         <p>feed_url:</p>
         <textarea name="feed_url" rows="4" cols="20"> <?php echo $feed_url?></textarea><br>
         <input type="submit" value="Ret" name="submit"/>
         </form>




</body>
</html>