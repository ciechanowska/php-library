<?php 
include 'administrations_panel/db_conection.php';
$feed_id=$_GET['feed_id'];
$sql="DELETE FROM admin WHERE feed_id=$feed_id";
$result= mysqli_query($connection, $sql);

header("Location: listevisning.php");exit;





