-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Vært: 127.0.0.1
-- Genereringstid: 15. 03 2016 kl. 13:59:35
-- Serverversion: 5.6.16
-- PHP-version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rss`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `feed_id` int(11) NOT NULL AUTO_INCREMENT,
  `feed_titel` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `feed_url` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`feed_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Data dump for tabellen `admin`
--

INSERT INTO `admin` (`feed_id`, `feed_titel`, `feed_url`) VALUES
(1, 'kultur', 'http://www.dr.dk/Nyheder/Service/feeds/Kultur'),
(2, 'politik', 'http://www.dr.dk/Nyheder/Service/feeds/Politik'),
(3, 'udland', 'http://www.dr.dk/Nyheder/Service/feeds/Udland'),
(4, 'penge', '   http://www.dr.dk/nyheder/service/feeds/penge      ');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
