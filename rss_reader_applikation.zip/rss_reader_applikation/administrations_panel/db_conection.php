<?php
$host="localhost";
$user="root";
$password="";
$database="rss";

$connection= mysqli_connect($host, $user, $password, $database) or die("Ingen forbindelse til databasen");
$charset= mysqli_set_charset($connection, "utf8");
?>