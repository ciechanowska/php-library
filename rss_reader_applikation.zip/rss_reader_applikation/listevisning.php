<?php include 'administrations_panel/db_conection.php';?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Listevisning</title>
</head>

<body>
<?php
$sql="SELECT * FROM admin";
$result= mysqli_query($connection, $sql);
 while($row=mysqli_fetch_array($result)) {
	
	 echo"<article>";
	 echo"<h2>$row[feed_titel]</h2>";
	 echo"<p>";
	 echo"<b>$row[feed_url]</b><br>";
	 //echo "<li><a href='showimage.php?feed_id="  . $row['feed_id'] . "'>" . $row['feed_url'] . "</a></li>
//		";
	 echo"</p>";
	 echo"<p><a href='delete.php?feed_id=$row[feed_id]'>Slet</a>";
	 echo"<p><a href='edit.php?feed_id=$row[feed_id]'>Ret</a>";
	 echo"<hr></article>";
 }
 
 echo"<p><br><a href='new.php'>Opret ny feed</a>";

?>
</body>
</html>