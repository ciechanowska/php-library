<?php include 'administrations_panel/db_conection.php';?>
<!doctype html>
<html>
     <head>
       
       <title>CRUD</title>
</head>

<body> 

<?php
if (isset($_POST['submit']))
{
     $feed_titel= $_POST['feed_titel'];
	 $feed_url= $_POST['feed_url'];
	
	 

	 
	 $sql="INSERT INTO admin (feed_titel, feed_url) VALUES ('$feed_titel', '$feed_url')";
	 mysqli_query($connection, $sql);
}

?>
    <form method="post">
         <p>feed_titel:</p>
         <input type="text" name="feed_titel" value=""/><br>
        
         <p>feed_url:</p>
         <textarea name="feed_url" rows="4" cols="20">
         </textarea><br>
         <input type="submit" value="Opret" name="submit"/>
         </form>
     <p><a href="listevisning.php">Tilbage til listevisning</a></p>
         



</body>
</html>